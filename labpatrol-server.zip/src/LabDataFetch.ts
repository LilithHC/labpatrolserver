import {TableSchema, DataStore} from "./DataStore"

export class LabDataFetch {
    dbName:string=''
    dbStore:DataStore|undefined
    constructor() {
        this.dbStore = new DataStore()

    }

    async openDb(dbName:string) {
        this.dbName = dbName
        await this.dbStore?.createDb(dbName)
    }


    async queryExaCard() {
        let rows = await this.dbStore?.queryAll('exacurrent') as TableSchema[]
        let exaCard:TableSchema[] =[]
        let tableName = ''
        if (rows && rows.length > 0) {
            tableName = rows[0].name
            exaCard = await this.dbStore?.queryAll(tableName) as TableSchema[]
        }
        return exaCard;
    }

    async queryAxosCard() {
        let rows = await this.dbStore?.queryAll('axoscurrent') as TableSchema[]
        let exaCard:TableSchema[] =[]
        let tableName = ''
        if (rows && rows.length > 0) {
            tableName = rows[0].name
            exaCard = await this.dbStore?.queryAll(tableName) as TableSchema[]
        }
        return exaCard;
    }    
}