class MokeData {
    constructor() {

    }

    static mokeAxosCard() {
        
 

    }

}



